#!/bin/bash 

# Paths
BASE=`pwd`
OCTAVE="/usr/bin/octave"
OCTAVE_LIBS=$BASE/experimentos/gp/effort/scripts
CLASSPATH=$BASE/bin/
LIB=$BASE/lib

DATA_DIR=data/
MEASURES_DIR=measures/

K_HEADER="generation initA initB initC initD avgNodesIndGen avgNodesTreeAGen avgNodesIndRun avgDepthIndGen avgDepthTreeAGen avgDepthIndRun meanRawGen meanAdjustedGen meanHitsGen bestRawGen bestAdjustedGen bestHitsGen bestRawRun bestAdjustedRun bestHitsRun"

# Statistics
SR="true"
SR_CONDITION="=="
SR_FITNESS=0
SR_COLUMN=15

KOZA_E=0.001

if [ $# -ne 1 ]
then
	echo SYNTAX: $0 file.params
	exit 
fi

echo Reading configuration
# $1 --> ECJ parameters file
CONFIG_FILE=`pwd`/$1

N=`find $DATA_DIR -name "run-*" -print | xargs ls | wc -l`
POPULATION=`testParameters.sh $CONFIG_FILE | grep pop.subpop.0.size |cut -d' ' -f 3`
GENERATIONS=`testParameters.sh $CONFIG_FILE | grep generations |cut -d' ' -f 3`

echo Calculating average
mkdir $MEASURES_DIR 2> /dev/null
$OCTAVE -qf $OCTAVE_LIBS/average.m $GENERATIONS $N
echo $R_HEADER > measures/average.dat
grep -v "#" < average.dat >> measures/average.dat
rm average.dat

echo "Extracting Successes"
generate_k.R $N $SR_COLUMN $SR_CONDITION $SR_FITNESS $KOZA_E $POPULATION
