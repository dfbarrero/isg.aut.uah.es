function [NumberOfZeros]=zerocrossing(signal_sampling)

%This function calulates the number of Zeros having audio signal.
%
%[NumberOfZeros]=zerocrossing(signal_sampling,N)
%
%NumberOfZeros: Number of Zeros in the audio signal.
%signal_sampling: It is the signal to evaluate.
%N: Number of samples.

Zeros=0;
for i=2:1:length(signal_sampling)
    Zeros=Zeros+abs(sign(signal_sampling(i))-sign(signal_sampling(i-1)));
end;

NumberOfZeros=Zeros/2;

end