function [signal_samples,Fs]= sampling(nombre_cancion)
%[fft_audio_signal,signal_samples,Fs,N]= sampling(nombre_cancion)
%
%This function obtains the fft and the samples of a audio signal.
%fft_audio_signal: the fast fourier transform of the signal samples.
%signal samples: Samples of a audio signal at Fs frecuency.
%Fs frecuency sampling.
%N: number of samples.

    [cancion,Fs]=mp3read(nombre_cancion);
    mono=(cancion(:,1)+cancion(:,2))./2;
    signal_samples=mono';
end

    