function [Rm,Rstd]=rolloff(signal,window_length)
%This function obtains the roloff factor of a signal audio across its fft.

window=(hamming(window_length))'; %Enventanado
number_frames=ceil(length(signal)/window_length); %Numero de ventanas a utilizar;
R=ones(1,number_frames);

for i=1:number_frames-1
    
    framei=signal(((i-1)*window_length)+1:i*window_length).*window;
    spectri=abs(fft(framei,window_length));
    aux=0.85*sum(spectri(1:window_length/2));%Cogemos la mitad del espectro%
    aux2=0;
    while (aux2<=aux && R(i)<=window_length/2)
        aux2=sum(spectri(1:R(i)));
        R(i)=R(i)+1;
    end;
    R(i)=R(i)-1;
end;
i=i+1;
framei=signal(((i-1)*window_length)+1:end);
framei=framei.*window(1:length(framei));
    spectri=abs(fft(framei,length(framei)));
    aux=0.85*sum(spectri(1:ceil(length(framei)/2)));%Cogemos la mitad del espectro
    aux2=0;
    while (aux2<=aux && R(i)<=ceil(length(framei)/2))
        aux2=sum(spectri(1:R(i)));
        R(i)=R(i)+1;
    end;
    R(i)=R(i)-1;
Rm=mean(R);
Rstd=std(R);
end