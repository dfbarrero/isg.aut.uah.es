% Specify the folder where the files live.
myFolder = 'E:\Redx\Desktop\cosas_beca\pruebas_matlab\sonidos_finales\war';
% Check to make sure that folder actually exists.  Warn user if it doesn't.
if ~isdir(myFolder)
  errorMessage = sprintf('Error: The following folder does not exist:\n%s', myFolder);
  uiwait(warndlg(errorMessage));
  return;
end

fid=fopen('primer_testwar.arff','w');
fprintf(fid,'@RELATION\tHFalls.arff\n\n');
fprintf(fid,'@ATTRIBUTE\tEm\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tEstd\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tNOZ\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tCm\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tCstd\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tRm\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tRstd\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tFm\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tFstd\tNUMERIC\n');
fprintf(fid,'@ATTRIBUTE\tclass\t{Fall,NotFall}\n\n');
fprintf(fid,'@DATA\n');



fprintf(fid,'\n\n\n\n%%Inicio de no caidas\n\n\n\n');

% Get a list of all files in the folder with the desired file name pattern.
filePattern2 = fullfile(myFolder, '*n.mp3'); % Change to whatever pattern you need.
theFiles2 = dir(filePattern2);

for k = 1 : length(theFiles2)
  baseFileName2 = theFiles2(k).name;
  fullFileName2 = fullfile(myFolder, baseFileName2);
  fprintf(1,'Analizando: %s\n',fullFileName2);
  [signal2,Fs2]=sampling(fullFileName2);
  [Em2,Estd2,signal_mod2]=energy(signal2,2048);
  NOZ2=zerocrossing(signal2);
  [Cm2,Cstd2]=centroide(signal_mod2,2048);
  [Rm2,Rstd2]=rolloff(signal_mod2,2048);
  [Fm2,Fstd2]=flux(signal_mod2,2048);


  fprintf(fid,'%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,NotFall\n',Em2,Estd2,NOZ2,Cm2,Cstd2,Rm2,Rstd2,Fm2,Fstd2);
  
end


fprintf(fid,'\n\n\n\n%%Inicio de las caidas\n\n\n\n');

% Get a list of all files in the folder with the desired file name pattern.
filePattern = fullfile(myFolder, '*f.mp3'); % Change to whatever pattern you need.
theFiles = dir(filePattern);

for k = 1 : length(theFiles)
  baseFileName = theFiles(k).name;
  fullFileName = fullfile(myFolder, baseFileName);
  fprintf(1,'Analizando: %s\n',fullFileName);
  [signal,Fs]=sampling(fullFileName);
  [Em,Estd,signal_mod]=energy(signal,2048);
  NOZ=zerocrossing(signal);
  [Cm,Cstd]=centroide(signal_mod,2048);
  [Rm,Rstd]=rolloff(signal_mod,2048);
  [Fm,Fstd]=flux(signal_mod,2048);


  fprintf(fid,'%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,%.10f,Fall\n',Em,Estd,NOZ,Cm,Cstd,Rm,Rstd,Fm,Fstd);
  
end





fclose(fid);