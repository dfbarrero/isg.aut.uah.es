function [Fm,Fstd]=flux(signal,window_length)

%This function obtains the spectral flux of a signal. 

window=(hamming(window_length))'; %Enventanado
number_frames=ceil(length(signal)/window_length); %Numero de ventanas a utilizar;
F=ones(number_frames,window_length);

for i=1:number_frames-2
    FFT1=abs(fft(signal((((i-1)*window_length)+1):window_length*i))).*window;
    FFT2=abs(fft(signal((((i)*window_length)+1):window_length*(i+1)))).*window;
    F(i,:)=abs(FFT2-FFT1);
end;
i=i+1;
FFT1=abs(fft(signal((((i-1)*window_length)+1):window_length*i))).*window;
FFT2=abs(fft(signal((((i)*window_length)+1):end)));
FFT2=FFT2.*window(1:length(FFT2));
F(i,:)=[abs(FFT2-FFT1(1:length(FFT2))),zeros(1,window_length-length(FFT2))];

Fm=mean(mean(F,2));
Fstd=std(std(F,1,2));
end
    
    