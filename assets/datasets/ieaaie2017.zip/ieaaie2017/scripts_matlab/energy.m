function [Em,Estd,signal_modif]=energy(signal,window_length)

%This function obtains the average energy of a audio signal and calculates
% the percentage of time that energy is lower of average.

number_frames=ceil(length(signal)/window_length);
E=zeros(1,number_frames); %Energy vector
signal_modif=[];%New signal which doesn�t contain silences.

for i=1:number_frames-1
    framei=signal((((i-1)*window_length)+1):window_length*i);
    E(i)=sum(abs(framei.^2));
    E(i)=E(i)/window_length;% Energy of the frame.
    if(E(i)>=9.2376e-6) 
        signal_modif=horzcat(signal_modif,framei);
    end;
end;
i=i+1;
framei=signal(((i-1)*window_length+1):end);
E(i)=sum(abs(framei.^2));
E(i)=E(i)/length(framei);
if(E(i)>=9.2376e-6) 
   signal_modif=[signal_modif,framei];
end;
        
Em=mean(E);
Estd=std(E);

end
