function [Cm,Cstd]=centroide(signal,window_length)

window=(hamming(window_length))'; %Enventanado de 2048 puntos.
number_frames=ceil(length(signal)/window_length); %Numero de ventanas a utilizar;
f=(1:window_length);
C=zeros(1,number_frames);
for i=1:1:number_frames-1;
    
    framei=signal(((i-1)*window_length)+1:i*window_length).*window;
    spectri=abs(fft(framei,window_length));
    C(i)=sum(f.*spectri)/sum(spectri);
    if(isnan(C(i)))
        C(i)=0;
    end;
end;
i=i+1;
framei=signal(((i-1)*window_length)+1:end);
framei=framei.*window(1:length(framei));
spectri=abs(fft(framei,length(framei)));
C(i)=sum(f(1:length(spectri)).*spectri)/sum(spectri);
if(isnan(C(i)))
    C(i)=0;
end;
    

Cm=mean(C);%Media
Cstd=std(C);%Desviacion tipica
end

    