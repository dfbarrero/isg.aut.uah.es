In the pp_forward directory we can find the pre-processed datasets for the forward falls, the ones which were used to train the classifier are the ones which follow the pXrd template, the mPruebaXr and pPruebaXr are also forward falls but from other subjects.

In  the pp_syncope directory we can find the pre-processed datasets for the syncope falls.

In the raw_syncope and raw_forward we can find all the datasets without being pre-processed, as happened with the pp_forward we have the forward falls dataset for the three subjects.

The notFall dataset is the dataset we used to train the classifiers representing the "not Fall" class.

finally in the scripts directory we can find a python script used to parse the csv dataset to arff files which can be read by weka, adding the mean and standard deviation for the specified window size.