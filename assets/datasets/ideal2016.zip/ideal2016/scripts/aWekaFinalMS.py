#Script para filtrar los datos recogidos con la app de Android del acelerometro
#Se llevaran al fichero de salida los valores de la aceleracion de x y z y el numero de la ventana
#Ademas se debera especificar la actividad que se esta realizando
#Con formato NumW,X.xxxx1,Y.yyyy1,Z.zzzz1,...,Actividad
#Ej --> aWekaFinal.aweka("andando1.csv","out1","Andando")
#	Dara salidas como: 0,-10.09799,-4.34578,-0.59631,....,Andando
#
#aWekaFinal.todo("andando1.csv","BrazoH1.csv","brazoV.csv","quieto.csv","corriendo1.csv","outTodoNormal","Andando","BrazoH","BrazoV","Quieto","Corriendo")
#
#Con todo se concatenan todos los datos de entrada al fichero de salida, por defecto esta a 5 archivos, pero se puede rellenar con "" y listo
#El parametro window esta inicializado por defecto a 25, es el numero de muestras por ventana
#frec esta inicializado por defecto a 1, cuanto mas aumente la frecuencia menos muestras se tendran en cuenta, con 2 1/2, 3 1/3 etc 
#Por defecto el quinto fichero de entrada tiene la frecuencia duplicada ya que los datos de "Corriendo" se tomaron a 10 ms
#se generara una cabecera de Weka automaticamente, en caso de querer adjuntar comentarios se debera hacer a mano
#Ejemplo:
#% 
#% Datos recogidos por el acelerometro andando
#% Muestras tomadas cada 20 ms
#% Numero de datos recogidos 2085
#% Los atributos seran los valores del acelerometro en x y z
#% Hora de inicio: 1970-01-01 19:28:32.625
#% Hora de fin: 1970-01-01 19:29:14.505
#% Tiempo transcurrido: 41880 ms
#
#@RELATION outTodoNormal
#
#@ATTRIBUTE	NumW	NUMERIC
#@ATTRIBUTE	AcelX1	NUMERIC
#@ATTRIBUTE	AcelY1	NUMERIC
#@ATTRIBUTE	AcelZ1	NUMERIC
#...
#...
#...
#@ATTRIBUTE	class	{Andando,Corriendo,Quieto,BrazoV,BrazoH}
#
#@DATA	
#En los atributos se tendran que incluir tantas aceleraciones x y z como el numero de muestras de la ventana.
#Hay que actualizar los comentarios Dia 15/2/2016  --> aWekaFinalMS.pruebasCaida("sinCaidaB3.csv","D3MS253.arff","MS")
#
#
#Script preparado para preparar para Weka los datos recogidos de las 30 caidas junto con un dataset con datos sin caidas
#Con la funcion pruebasCaida a la que debemos pasar 3 atributos obligatorios y 2 opcionales
#El primero sera el dataset con los datos de "NoCaida" el segundo el fichero de salida, recomendable anyadir .arff para
#tratarlo directamente con weka, el tercero sera el tipo de derivadas a anyadir, ya que la media y la desviacion tipica
#se anyaden por defecto, M para calcular la media del sumatorio de las derivadas, S para el sumatorio unicamente, MS para ambas y una 
#cadena vacia "" para no anyadir ninguna (realmente no se usan asi que para futuras pruebas con poner una cadena vacia o poner por defecto
#Una cadena vacia valdria ejemplo
#aWekaFinalMS.pruebasCaida("sinCaidaB3.csv","D32520.arff")
#por defecto el tamanyo de ventana esta a 25 muestras y la frecuencia a 20 ms, en caso de querer cambiarlo, el cuarto argumento es el
#tamanyo de la ventana y el quinto la frecuencia, para la frecuencia 1 = 20 ms 2 = 40 ms 3 = 60 ms etc sigue esa proporcion



import math

def iniciarCaida(infile1,infile2,infile3,infile4,infile5,outfile,act1,act2,act3,act4,act5,window=25,frec=1):
	
	with open(outfile, "a") as writefile:
		writefile.write("@RELATION\t"+outfile+"\n")
		writefile.write("\n\n@ATTRIBUTE\tNumW\tNUMERIC\n")
		for x in range(0,window):
			writefile.write("@ATTRIBUTE\tAcelX"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelY"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelZ"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaX"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaY"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaZ"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvX"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvY"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvZ"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tclass\t{Caida,NoCaida}")		
		writefile.write("\n\n@DATA\n\n\n")
	writefile.close()

	if (infile1!="" and act1!="") :
		aweka(infile1,outfile,act1,window,frec)
	if (infile2!="" and act2!="") :	
		aweka(infile2,outfile,act2,window,frec)
	if (infile3!="" and act3!="") :
		aweka(infile3,outfile,act3,window,frec)
	if (infile4!="" and act4!="") :	
		aweka(infile4,outfile,act4,window,frec)
	if (infile5!="" and act5!="") :
		aweka(infile5,outfile,act5,window,frec*2)

def pruebasCaida(infile1,outfile,tipo="",window=25,frec=1):
	
	with open(outfile, "a") as writefile:
		writefile.write("@RELATION\t"+outfile+"\n")
		writefile.write("\n\n@ATTRIBUTE\tNumW\tNUMERIC\n")
		for x in range(0,window):
			writefile.write("@ATTRIBUTE\tAcelX"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelY"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelZ"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaX\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaY\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaZ\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvX\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvY\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvZ\tNUMERIC\n")
		if (tipo=="S" or tipo=="MS"):
			writefile.write("@ATTRIBUTE\tDerivMX\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivMY\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivMZ\tNUMERIC\n")
		if (tipo=="M" or tipo=="MS"):
			writefile.write("@ATTRIBUTE\tDerivSX\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivSY\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivSZ\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tclass\t{Caida,NoCaida}")		
		writefile.write("\n\n@DATA\n\n\n")
	writefile.close()

	if (infile1!="") :
		aweka(infile1,outfile,"NoCaida",window,frec,tipo)
	aweka("caidafrontal1r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal2r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal3r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal4r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal5r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal6r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal7r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal8r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal9r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal10r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal11r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal12r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal13r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal14r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal15r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal16r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal17r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal18r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal19r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal20r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal21r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal22r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal23r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal24r.csv",outfile,"Caida",window,frec,tipo)
	#aweka("caidafrontal25r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal26r.csv",outfile,"Caida",window,frec,tipo)
	#aweka("caidafrontal27r.csv",outfile,"Caida",window,frec,tipo)
	#aweka("caidafrontal28r.csv",outfile,"Caida",window,frec,tipo)
	aweka("caidafrontal29r.csv",outfile,"Caida",window,frec,tipo)
	#aweka("caidafrontal30r.csv",outfile,"Caida",window,frec,tipo)
	
	
def pruebasCaida2(infile1,outfile,tipo="",window=25,frec=1):
	
	with open(outfile, "a") as writefile:
		writefile.write("@RELATION\t"+outfile+"\n")
		writefile.write("\n\n@ATTRIBUTE\tNumW\tNUMERIC\n")
		for x in range(0,window):
			writefile.write("@ATTRIBUTE\tAcelX"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelY"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelZ"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaX\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaY\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tMediaZ\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvX\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvY\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tDesvZ\tNUMERIC\n")
		if (tipo=="S" or tipo=="MS"):
			writefile.write("@ATTRIBUTE\tDerivMX\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivMY\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivMZ\tNUMERIC\n")
		if (tipo=="M" or tipo=="MS"):
			writefile.write("@ATTRIBUTE\tDerivSX\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivSY\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tDerivSZ\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tclass\t{Caida,NoCaida}")		
		writefile.write("\n\n@DATA\n\n\n")
	writefile.close()

	if (infile1!="") :
		aweka(infile1,outfile,"NoCaida",window,frec,tipo)
	aweka("p7rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p8rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p9rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p11rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p12rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p13rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p14rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p15rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p16rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p17rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p18rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p19rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p20rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p21rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p22rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p23rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p24rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p26rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p27rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p28rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p29rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p30rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p31rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p32rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p33rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p34rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p35rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p36rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p38rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p39rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p40rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p42rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p43rd.csv",outfile,"Caida",window,frec,tipo)
	aweka("p47rd.csv",outfile,"Caida",window,frec,tipo)

def iniciar(infile1,infile2,infile3,infile4,infile5,outfile,act1,act2,act3,act4,act5,window=25,frec=1):
	
	with open(outfile, "a") as writefile:
		writefile.write("@RELATION\t"+outfile+"\n")
		writefile.write("\n\n@ATTRIBUTE\tNumW\tNUMERIC\n")
		for x in range(0,window):
			writefile.write("@ATTRIBUTE\tAcelX"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelY"+str(x)+"\tNUMERIC\n")
			writefile.write("@ATTRIBUTE\tAcelZ"+str(x)+"\tNUMERIC\n")
		writefile.write("@ATTRIBUTE\tclass\t{"+act1+","+act2+","+act3+","+act4+","+act5+"}")		
		writefile.write("\n\n@DATA\n\n\n")
	writefile.close()

	if (infile1!="" and act1!="") :
		aweka(infile1,outfile,act1,window,frec)
	if (infile2!="" and act2!="") :	
		aweka(infile2,outfile,act2,window,frec)
	if (infile3!="" and act3!="") :
		aweka(infile3,outfile,act3,window,frec)
	if (infile4!="" and act4!="") :	
		aweka(infile4,outfile,act4,window,frec)
	if (infile5!="" and act5!="") :
		aweka(infile5,outfile,act5,window,frec*2)

def anadir(infile1,infile2,infile3,infile4,infile5,outfile,act1,act2,act3,act4,act5,window=25,frec=1):
	
	if (infile1!="" and act1!="") :
		aweka(infile1,outfile,act1,window,frec)
	if (infile2!="" and act2!="") :	
		aweka(infile2,outfile,act2,window,frec)
	if (infile3!="" and act3!="") :
		aweka(infile3,outfile,act3,window,frec)
	if (infile4!="" and act4!="") :	
		aweka(infile4,outfile,act4,window,frec)
	if (infile5!="" and act5!="") :
		aweka(infile5,outfile,act5,window,frec*2)

def mediaX(args):
	
	total=0
	for x in range(0,len(args),3):
	        total=total+args[x]
	return(float(total)/(float(len(args))/float(3)))


def mediaY(args):

	total=0
	for x in range(0,len(args),3):
	        total=total+args[x+1]
	return(float(total)/(float(len(args))/float(3)))

def mediaZ(args):
		
	total=0
	for x in range(0,len(args),3):
	        total=total+args[x+2]
	return(float(total)/(float(len(args))/float(3)))

def desvX(args):
		
	sumatorio=0
	media=mediaX(args)
	for x in range(0,len(args),3):
		sumatorio=sumatorio+float((args[x]-media)*(args[x]-media))
	return(float(math.sqrt(float(sumatorio)/(float(len(args))/float(3)))))

def desvY(args):
		
	sumatorio=0
	media=mediaY(args)
	for x in range(0,len(args),3):
		sumatorio=sumatorio+float((args[x+1]-media)*(args[x+1]-media))
	return(float(math.sqrt(float(sumatorio)/(float(len(args))/float(3)))))

def desvZ(args):
		
	sumatorio=0
	media=mediaZ(args)
	for x in range(0,len(args),3):
		sumatorio=sumatorio+float((args[x+2]-media)*(args[x+2]-media))
	return(float(math.sqrt(float(sumatorio)/(float(len(args))/float(3)))))

def derivSX(args):
	
	sumatorio=0
	for x in range(0,len(args)-3,3):
		if(args[x+3]<0 or (args[x]<0 and args[x+3]>0 ) or (args[x]>0 and args[x+3]>0)):		
			sumatorio=sumatorio-float((args[x]-args[x+3]))
		else:
			sumatorio=sumatorio+float((args[x]-args[x+3]))
	return(sumatorio)

def derivSY(args):

	sumatorio=0
	for x in range(0,len(args)-3,3):
		if(args[x+4]<0 or (args[x+1]<0 and args[x+4]>0 ) or (args[x+1]>0 and args[x+4]>0)):		
			sumatorio=sumatorio-float((args[x+1]-args[x+4]))
		else:
			sumatorio=sumatorio+float((args[x+1]-args[x+4]))
	return(sumatorio)

def derivSZ(args):

	sumatorio=0
	for x in range(0,len(args)-3,3):
		if(args[x+5]<0 or (args[x+2]<0 and args[x+5]>0 ) or (args[x+2]>0 and args[x+5]>0)):		
			sumatorio=sumatorio-float((args[x+2]-args[x+5]))
		else:
			sumatorio=sumatorio+float((args[x+2]-args[x+5]))
	return(sumatorio)

def derivMX(args):

	sumatorio=0
	for x in range(0,len(args)-3,3):
		if(args[x+3]<0 or (args[x]<0 and args[x+3]>0 ) or (args[x]>0 and args[x+3]>0)):		
			sumatorio=sumatorio-float((args[x]-args[x+3]))
		else:
			sumatorio=sumatorio+float((args[x]-args[x+3]))
	return(float(sumatorio/(float(len(args)/3-1))))

def derivMY(args):

	sumatorio=0
	for x in range(0,len(args)-3,3):
		if(args[x+4]<0 or (args[x+1]<0 and args[x+4]>0 ) or (args[x+1]>0 and args[x+4]>0)):		
			sumatorio=sumatorio-float((args[x+1]-args[x+4]))
		else:
			sumatorio=sumatorio+float((args[x+1]-args[x+4]))
	return(float(sumatorio/(float(len(args)/3-1))))

def derivMZ(args):

	sumatorio=0
	for x in range(0,len(args)-3,3):
		if(args[x+5]<0 or (args[x+2]<0 and args[x+5]>0 ) or (args[x+2]>0 and args[x+5]>0)):		
			sumatorio=sumatorio-float((args[x+2]-args[x+5]))
		else:
			sumatorio=sumatorio+float((args[x+2]-args[x+5]))
	return(float(sumatorio/(float(len(args)/3-1))))

def aweka(infile,outfile,act,window=25,frec=1,tipo=""):
	data=[]
	datos=[]
	readfile=open(infile,"r")
	numw=0
	cont=-1
	aux=1
	for each_line in readfile:
		linea=each_line.split(",")
		if (len(linea)==10):
			if ((aux%frec)==0):
				data.append(linea)
				aux=aux+1			
			else:
				aux=aux+1
	numvent=len(data)-window
	stringu=""
	with open(outfile, "a") as writefile:
		writefile.write("\n\n%Inicio de la clase: "+act+"\n%Fichero: "+infile+"\n\n")			
		while(numw!=numvent):

			if(cont==window):
				numw=numw+1
				cont=-1
				stringu=stringu+","+str(mediaX(datos))+","
				stringu=stringu+str(mediaY(datos))+","
				stringu=stringu+str(mediaZ(datos))
				stringu=stringu+","+str(desvX(datos))+","
				stringu=stringu+str(desvY(datos))+","
				stringu=stringu+str(desvZ(datos))
				if (tipo =="M" or tipo =="MS"):			
					stringu=stringu+","+str(derivMX(datos))+","
					stringu=stringu+str(derivMY(datos))+","
					stringu=stringu+str(derivMZ(datos))				
				if (tipo =="S" or tipo =="MS"):				
					stringu=stringu+","+str(derivSX(datos))+","
					stringu=stringu+str(derivSY(datos))+","
					stringu=stringu+str(derivSZ(datos))				
				stringu=stringu+","+act
				writefile.write(stringu+"\n")
				datos=[]

			elif (cont==-1):
				stringu=str(numw)
				cont=0

			else:
				cont=cont+1
				stringu=stringu+","
				stringu=stringu+str(data[numw+cont][3])+"."
				stringu=stringu+str(data[numw+cont][4])+","
				stringu=stringu+str(data[numw+cont][5])+"."
				stringu=stringu+str(data[numw+cont][6])+","
				stringu=stringu+str(data[numw+cont][7])+"."
				stringu=stringu+str(data[numw+cont][8])
				if(float(data[numw+cont][3])<0 or (data[numw+cont][3]=="-0")):
					datos.append(float(data[numw+cont][3])-float(data[numw+cont][4])/float(100000))
				else:
					datos.append(float(data[numw+cont][3])+float(data[numw+cont][4])/float(100000))
				if(float(data[numw+cont][5])<0 or (data[numw+cont][5]=="-0")):
					datos.append(float(data[numw+cont][5])-float(data[numw+cont][6])/float(100000))
				else:
					datos.append(float(data[numw+cont][5])+float(data[numw+cont][6])/float(100000))
				if(float(data[numw+cont][7])<0 or (data[numw+cont][7]=="-0")):
					datos.append(float(data[numw+cont][7])-float(data[numw+cont][8])/float(100000))
				else:			
					datos.append(float(data[numw+cont][7])+float(data[numw+cont][8])/float(100000))
				
		writefile.write("\n\n%Fin de la clase: "+act+"\n\n")	

	readfile.close()
	writefile.close()

