#!/usr/bin/Rscript --vanilla

library(lattice)

#win <- T
#if (win) x11(width=8, height=6)

dataf <- data.frame(x=NULL, y=NULL, z=NULL)

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

data <- read.csv("prueba23.csv", header=F, sep=",", skip=2, dec=".")
print(head(data))
data <- data[,c(4,5,6)]

#colnames(data) <- c("ms","dt","Time","AccX","XXX", "AccY","YYY", "AccZ", "ZZZ", Event")
colnames(data) <- c("AccX", "AccY","AccZ")

print(head(data))

ylabel <- expression(Acceleration ~ (m/s^2))
xyplot(ts(data, frequency=50), xlab=list(label="Time (s)", cex=1.4), ylab=list(label=ylabel, cex=1.4), scales=list(cex=1.4))

#d <- melt(data, id.vars="Time")
#print(head(data))
#xyplot(AccX + AccY ~ Time, data)


#dev.copy2eps(file="acceleration.eps",  fonts="ComputerModern")
#if(win) while(1) Sys.sleep(1)

