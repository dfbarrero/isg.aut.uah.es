package uah.ecj.util;

import java.io.File;
import java.io.PrintWriter;
import java.io.Serializable;

import ec.util.ParameterDatabase;

@SuppressWarnings("serial")
    public class TestParameter implements Serializable 
    {
        /** Test the ParameterDatabase */
        public static void main(String[] args)
        {
            System.out.println("Reading " + args[0]);
            System.out.flush();
        
            try {
                ParameterDatabase pd = new ParameterDatabase(new File(args[0]), args);

                System.out.println("\n\n PRINTING ONLY VALID PARAMETERS \n\n");
                pd.list(new PrintWriter(System.out, true), false);
            } catch (Exception e) {
                System.out.println("Error reading parameter file: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

