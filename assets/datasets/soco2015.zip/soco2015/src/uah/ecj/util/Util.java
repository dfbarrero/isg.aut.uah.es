package uah.regex.util;

public class Util {
    /** It converts a string "11000" to an array of booleans */
    public static boolean[] stringToBooleanArray(String string) {
        boolean array[] = new boolean[string.length()];
                
        for (int i=0; i<string.length(); i++)
            array[i] = (string.charAt(i) == '1'? true: false);
        return array;
    }
        
    public static void printBoolean(boolean[] array) {
        System.out.print(Util.booleanArrayToString(array));
    }
        
    public static String booleanArrayToString(boolean[] array) {
        String string = "";
        for (boolean i: array) string += (i? "1" : "0");
                
        return string;
    }
        
    public static int booleanToInt(boolean[] array) {               
        return Integer.parseInt(Util.booleanArrayToString(array), 2);
    }
        
    public static int C(int l, int k) {
        if (k>l) throw new IllegalArgumentException ("k is > than n");
        return (int) (factorial(l)/(factorial(k) * (factorial(l-k))));
    }
        
    public static long factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("Received negative argument");
        if (n > 1) return(n*factorial(n-1));
        return(1);
    }
}
