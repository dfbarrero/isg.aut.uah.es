/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


/*
 * Created on Apr 16, 2005 12:36:14 PM
 * 
 * By: spaus
 */
package uah.ecj.stats;

import ec.simple.*;
import ec.EvolutionState;
import ec.util.Parameter;
import ec.vector.*;

/**
 * @author spaus
 */
@SuppressWarnings("serial")
    public class SimpleEvalStatistics extends SimpleStatistics {
        private int[] seriesID;
    
        public void setup(EvolutionState state, Parameter base) {
            super.setup(state, base);
        }
    
        public void postEvaluationStatistics(EvolutionState state) {
            super.postEvaluationStatistics(state);
        }

        public void finalStatistics(final EvolutionState state, final int result) {
            super.finalStatistics(state, result);

            state.output.println("Evaluations: " + ((SimpleEvolutionState)state).evaluator.evaluations, statisticslog);
        }
    }
