package uah.ecj;

import ec.EvolutionState;
import ec.Evolve;
import ec.util.Output;
import ec.util.Parameter;
import ec.util.ParameterDatabase;

public class MassiveEvolve extends Evolve {
        
    public static void main(String[] args) {
        EvolutionState state = null;
        ParameterDatabase parameters;

        parameters = loadParameterDatabase(args);
                
        int min = parameters.getIntWithDefault(new Parameter("job.init"), null, 1);
        if (min < 1)
            Output.initialError("The 'experiment.min' parameter must be >= 1 (or not exist, which defaults to 1)");

        int numJobs = parameters.getIntWithDefault(new Parameter("jobs"), null, 1);
        if (numJobs < 1)
            Output.initialError("The 'jobs' parameter must be >= 1 (or not exist, which defaults to 1)");            
        if (numJobs < min)
            Output.initialError("The 'jobs' parameter must be >= 1 job.init");            
                
        for (int job = min; job <= numJobs; job++) {
            parameters = loadParameterDatabase(args);
                        
            // Initialize the EvolutionState, then set its job variables
            state = initialize(parameters, job); // pass in job# as the seed increment
                        
            System.out.print(job + " ");
                        
            state.job = new Object[1]; // make the job argument storage
            state.job[0] = new Integer(job); // stick the current job in our job storage
            state.runtimeArguments = args; // stick the runtime arguments in our storage

            // Here you can set up the EvolutionState's parameters further before it's setup(...).
            // This includes replacing the random number generators, changing values in state.parameters,
            // changing instance variables (except for job and runtimeArguments, please), etc.
            String prefix1 = parameters.getString(new Parameter("stat.file"), null);
            String prefix2 = parameters.getString(new Parameter("stat.child.0.file"), null);
                        
            // Set output file name
            //parameters.set("stat.file", "job." + job + prefix1);
			parameters.set(new Parameter("stat.file"), "job." + job + "." + prefix1);
			parameters.set(new Parameter("stat.child.0.file"), "job." + job + "." + prefix2);
                        
            // now we let it go
            state.run(EvolutionState.C_STARTED_FRESH);
            cleanup(state); // flush and close various streams, print out parameters if necessary
            parameters = null; // so we load a fresh database next time around
        }

        System.exit(0);
    }
}
