#!/bin/bash 

# Paths
BASE=/Users/david/Documents/investigacion/repositorios/gp+em2011/trunk/code
BASE=/home/dbarrero/repositorios/gp+em2011/trunk/code/
LIB=$BASE/lib

for I in $LIB/*
do
	CLASSPATH=$CLASSPATH:$I
done

# Dot slash is used in the execution of TestParameter to avoid a bug in ECJ, the parameter file must be provided with a directory
PROBLEM=`basename $1`
PROBLEM=${PROBLEM%\.*}
echo $PROBLEM
#echo Warning: There must be a directory in the provided path
java -classpath $CLASSPATH uah.ecj.util.TestParameter $1
