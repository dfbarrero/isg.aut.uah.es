#!/usr/bin/Rscript --vanilla

data <- data.frame(problem=NULL, evaluations=NULL, tournament=NULL)

for (path in dir(path="../experimentos-tour7/data/", pattern="*")) {
		file <- paste("../experimentos-tour7/data/", path, "/es.dat", sep="")
		print(paste("Reading ", file))
 	   	temp <-read.table(file, header=F)$V1
		#print(temp)
		temp <- temp[temp<max(temp)]

		if (length(temp) > 0) {
			# There are successes in the experiment
			temp <- data.frame(problem=path, evaluations=temp, tournament=7)
			cat("7:", path, nrow(temp), "\n")
			data <- rbind(data, temp)
		}
}

for (path in dir(path="../experimentos-tour1/data/", pattern="*")) {
		file <- paste("../experimentos-tour1/data/", path, "/es.dat", sep="")
		print(paste("Reading ", file))
 	   	temp <-read.table(file, header=F)$V1
		#print(temp)
		temp <- temp[temp<max(temp)]

		if (length(temp) > 0) {
			# There are successes in the experiment
			temp <- data.frame(problem=path, evaluations=temp, tournament=1)
			cat("1:", path, nrow(temp), "\n")
			data <- rbind(data, temp)
		}
}

write.csv(data, file="dataset.csv", row.names=FALSE)
