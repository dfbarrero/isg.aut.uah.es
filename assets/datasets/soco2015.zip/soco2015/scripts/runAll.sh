#!/bin/bash 

# Paths
BASE=/home/dbarrero/repositorios/gp+em2011/trunk/code/
SCRIPTS=$BASE/scripts
CLASSPATH=
LIB=$BASE/lib/


echo running the whole set of experiments

for I in *.params
do
	$SCRIPTS/run.sh $I
done 
