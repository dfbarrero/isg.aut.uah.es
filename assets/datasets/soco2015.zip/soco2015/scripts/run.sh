#!/bin/bash 

# Paths
BASE=/home/dbarrero/repositorios/gp+em2011/trunk/code
SCRIPTS=$BASE/scripts
CLASSPATH=
LIB=$BASE/lib/
JOBS=20000
COUNT=$INIT

typeset -i COUNT
typeset -i JOBS
typeset -i INIT

# $1 --> ECJ parameters file
CONFIG_FILE=`pwd`/$1

for I in $LIB/*
do
	CLASSPATH=$CLASSPATH:$I
done

if [ -z "$1" ]
then
	echo ERROR: $0 file.params
	exit 
fi

DATA=`basename $1 |cut -d "." -f 1`

echo "data/$DATA"

if [ ! -d "data/$DATA" ]
then	
	# Primer job
	INIT=1
	mkdir data/$DATA
else	
	INIT=`ls -l data/$DATA/*gz|wc -l`
	INIT=`expr $INIT`
fi

if [ $JOBS -le $INIT ]
then
	echo Run finished
	exit 0
fi

echo Running ECJ params $1

while [ $INIT -ne $JOBS ]
do
	echo INIT: $INIT JOBS: $JOBS
	java -classpath $CLASSPATH uah.ecj.MassiveEvolve -file $CONFIG_FILE -p jobs=$JOBS -p job.init=$INIT 2> $DATA.error |tee $DATA.log
	ERROR=$?
	mv job*simple data/$DATA
	mv job* data/$DATA 
	INIT=`ls -l data/$DATA/*gz|wc -l`
	if [ $ERROR -ne 0 ]
	then
		INIT=`expr $INIT`
		echo ERR
	else
		INIT=$JOBS
	fi
done

echo
echo Processing data
$SCRIPTS/process_data.sh data/$DATA 

echo
