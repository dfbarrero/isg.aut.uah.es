#!/usr/bin/Rscript --vanilla

library(lattice)

generationsL <- 800
generationsR <- 0

probL <- seq(0.015, 0.015, length=generationsL)
probR <- seq(0.025, 0, length=generationsR)
prob <- c(probL, probR)
generations <- generationsL+generationsR
p <- rep(0, generations)
gen <- 1:generations-1

for (j in gen) {
  p[j] <- prob[j]
  for (i in 1:j) {
    p[j] <- p[j] * (1-prob[i])
  }
}

plot(p, type="l", xlim=c(0, 800), col="black", xlab="Generation", ylab="Density")

generationsL <- 800
generationsR <- 0

probL <- seq(0, 0.025, length=generationsL)
probR <- seq(0.025, 0, length=generationsR)
prob <- c(probL, probR)
generations <- generationsL+generationsR
p <- rep(0, generations)
gen <- 1:generations-1

for (j in gen) {
  p[j] <- prob[j]
  for (i in 1:j) {
    p[j] <- p[j] * (1-prob[i])
  }
}

lines(p, col="red")

generationsL <- 400
generationsR <- 400

probL <- seq(0, 0.025, length=generationsL)
probR <- seq(0.025, 0, length=generationsR)
prob <- c(probL, probR)
generations <- generationsL+generationsR
p <- rep(0, generations)
gen <- 1:generations-1

for (j in gen) {
  p[j] <- prob[j]
  for (i in 1:j) {
    p[j] <- p[j] * (1-prob[i])
  }
}

lines(p, type="l", col="blue")

legend("topright", c("Prob. constante - Exponential", "Prob. creciente - Weibull?", "Prob. triangular - Lognormal?"), col=c("black", "red", "blue"), lty=1)
