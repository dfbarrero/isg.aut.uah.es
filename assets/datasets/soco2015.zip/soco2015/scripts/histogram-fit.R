#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(lattice)

print("hola")
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

file <- c( "data.dat")
file <- c( "data-tour.dat")
#labels <- factor(c("A*", "Basic Theta", "H-Theta"), ordered=TRUE)

#if (win) x11(width=8, height=6)

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

a <- read.table(file, header=T)
colnames(a)
x11()
print("hola")

histogram(~ evaluations | problem, data=a, col="red", as.table=TRUE,
        type="density", allow.multiple=TRUE, #aspect="y",
        #scales=list(relation="free"), as.table=TRUE, layout=c(3,2),aspect="y",
        xlab="Run-time (seconds)", ylab="Density", breaks=NULL, cex=0.7,
		#auto.key = list(text = c("Lognormal","Weibull", "Exponential"), columns=3, col=c("blue", "green", "black"), lines=TRUE, points=FALSE),
		key = simpleKey(text = c("Lognormal","Weibull", "Normal"), columns=3, lines=TRUE, points=FALSE),
		scales = list(relation="free"),
#	   index.cond=list(c(5,2,4,6,3,1)),
	    panel = function(x, ...) {
	        panel.histogram(x, ...) 

    		param <- fitdistr(x, densfun="weibull")$estimate
 	  		llines(1:max(x), dweibull(1:max(x), shape=param[1],scale=param[2]), col="green")
			param <- fitdistr(x, densfun="Lognormal")$estimate
			llines(1:max(x),dlnorm(1:max(x), meanlog=param[1], sdlog=param[2], log=F), col="black")
			param <- fitdistr(x, densfun="normal")$estimate
			llines(1:max(x),dnorm(1:max(x), mean=param[1], sd=param[2], log=F), col="blue")
			#param <- fitdistr(x[x!=0], densfun="gamma", lower = 0.002)$estimate
			print(param)
			#llines(1:max(x),dgamma(1:max(x), shape=param[1], rate=param[2], log=F), col="brown")
		})

dev.copy2eps(file="histogram-fit.eps",  fonts="ComputerModern")
while(1) Sys.sleep(1)
