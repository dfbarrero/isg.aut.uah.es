#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(e1071)
library(MASS)
library(fitdistrplus)
library(xtable)

print("hola")
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

a <- read.table("../data.dat", header=T)
colnames(a)
x11()

options(digits=2)
#par(mfrow=c(2,2))

result <- data.frame(problem=NULL, mean=NULL, sd=NULL, kurtosis=NULL, skewness=NULL)
for (problem in unique(a$problem)) {
	p <- problem

	data <- subset(a, problem==p)
	res <- descdist(data$evaluations, discrete = FALSE, boot=100)
#	Sys.sleep(5)
	#hist(data$pathLength, main=paste(problem, obstacles))
	result <- rbind(result, data.frame(problem=p,
		mean=mean(data$evaluations),
		sd=sd(data$evaluations),
		kurtosis=res$kurtosis,
		skewness=res$skewness))
}

fm1.table <- xtable(result, digits=2)
##print(fm1.table)
print(fm1.table,type="latex")
#dev.copy2eps(file="cullen-fry.eps",  fonts="ComputerModern")
while(1) Sys.sleep(1)
