#!/usr/bin/Rscript --vanilla

library(car)
library(MASS)
library(fitdistrplus)

x11()
layout(matrix(c(1,1,1,2,3,4), 2, 3, byrow=TRUE), heights=c(1.5,1))

#par(mar=c(1.4,1.1,0,0), oma=c(1,1,2,0.2), mgp=c(2, 1, 0), cex=0.8)
par(mgp=c(2, 1, 0), cex=0.8)
n <- 100

generationsL <- 800
generationsR <- 0

probL <- seq(0.015, 0.015, length=generationsL)
probR <- seq(0.025, 0, length=generationsR)
prob <- c(probL, probR)
generations <- generationsL+generationsR
p <- rep(0, generations)
k <- rep(0, generations)
const <- rep(NA, n)
crec <- rep(NA, n)
trig <- rep(NA, n)
gen <- 1:generations-1

# Density
for (j in gen) {
  p[j] <- prob[j]
  for (i in 1:j) {
    p[j] <- p[j] * (1-prob[i])
  }
}

# Generate samples
for (j in 1:n) {
  for (i in gen+1) {
    if (runif(1) < p[i]) {
      const[j] <- i
    }
  }
}

plot(p, type="l", xlim=c(0, 800), ylim=c(0,0.010), col="black", xlab="Generation", ylab="Density")

# --------------------
n <- 200
generationsL <- 800
generationsR <- 0

probL <- seq(0, 0.025, length=generationsL)
probR <- seq(0.025, 0, length=generationsR)
prob <- c(probL, probR)
generations <- generationsL+generationsR
p <- rep(0, generations)
gen <- 1:generations-1

for (j in gen) {
  p[j] <- prob[j]
  for (i in 1:j) {
    p[j] <- p[j] * (1-prob[i])
  }
}

# Generate samples
for (j in 1:n) {
  for (i in gen+1) {
    if (runif(1) < p[i]) {
      crec[j] <- i
    }
  }
}

lines(p, col="red")

#-------------
n <- 200

generationsL <- 400
generationsR <- 400

probL <- seq(0, 0.025, length=generationsL)
probR <- seq(0.025, 0, length=generationsR)
prob <- c(probL, probR)
generations <- generationsL+generationsR
p <- rep(0, generations)
gen <- 1:generations-1

for (j in gen) {
  p[j] <- prob[j]
  for (i in 1:j) {
    p[j] <- p[j] * (1-prob[i])
  }
}

# Generate samples
for (j in 1:n) {
  for (i in gen+1) {
    if (runif(1) < p[i]) {
      trig[j] <- i
    }
  }
}

lines(p, type="l", col="blue")

legend("topright", c("f1", "f2", "f3"), col=c("black", "red", "blue"), box.col="white", lty=1)

#-----------
#qqPlot(crec, distribution="lnorm", main="Q-Q f2 vs. exp.", xlab="Exp. quantiles", ylab="Sample quantiles")
#qqPlot(trig, distribution="weibull", main="Q-Q f3 vs. exp.", xlab="Exp. quantiles", ylab="Sample quantiles")

const <- const[!is.na(const)]
fconst <- fitdist(const, "exp")
#fwr<-gofstat(fw, print=T)
test <- ks.test(const, "pexp", rate=fconst$estimate[1])
#print(test)
testconst <- NULL
testconst$p <- test$p.value
testconst$ks <- test$statistic
theo <- rexp(length(const), rate=fconst$estimate[1])
for (i in 1:100) theo[theo>800] <- rexp(1, rate=fconst$estimate[1])
qqplot(const, theo, main="f1 - exp.", xlab="Exp. quantiles", ylab="Sample quantiles")
abline(0,1,col="darkgrey")
grid()

crec <- crec[!is.na(crec)]
fcrec <- fitdist(crec, "weibull")
#fwr<-gofstat(fw, print=T)
testcrec <- ks.test(crec, "pweibull",  shape=fcrec$estimate[1], scale=fcrec$estimate[2])
##print(test)
##print("hola")
##fcrec <- NULL
##fcrec$p <- test$p.value
##fcrec$ks <- test$statistic
theo <- rweibull(length(crec), shape=fcrec$estimate[1], scale=fcrec$estimate[2])
for (i in 1:100) theo[theo>800] <- rweibull(1, shape=fcrec$estimate[1], scale=fcrec$estimate[2])
qqplot(crec, theo, main="f2 - Weibull", xlab="Exp. quantiles", ylab="Sample quantiles")
abline(0,1,col="darkgrey")
grid()

trig <- trig[!is.na(trig)]
ftrig <- fitdist(trig, "lnorm")
#print(ftrig)
#fwr<-gofstat(fw, print=T)
testtrig <- ks.test(trig, "plnorm",  meanlog=ftrig$estimate[1], sdlog=ftrig$estimate[2])
##print(test)
##ftrig <- NULL
##ftrig$p <- test$p.value
##ftrig$ks <- test$statistic
theo <- rlnorm(length(trig), meanlog=ftrig$estimate[1], sdlog=ftrig$estimate[2])
for (i in 1:100) theo[theo>800] <- rlnorm(1, meanlog=ftrig$estimate[1], sdlog=ftrig$estimate[2])
qqplot(trig, theo, main="f3 - lognormal", xlab="Exp. quantiles", ylab="Sample quantiles")
abline(0,1,col="darkgrey")
grid()

print("Constante:")
print(testconst)
print("Creciente:")
print(testcrec)
print("Trig:")
print(testtrig)

dev.copy2eps(file="../../../tex/figs/simulation.eps",  fonts="ComputerModern")

while(1) Sys.sleep(1)
