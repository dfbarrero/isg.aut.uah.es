#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(lattice)

print("hola")
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

file <- c( "../data.dat")
#labels <- factor(c("A*", "Basic Theta", "H-Theta"), ordered=TRUE)

#if (win) x11(width=8, height=6)

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

a <- read.table(file, header=T)
colnames(a)
x11()

histogram(~ evaluations | problem, data=a, col="red",
		type="density", allow.multiple=TRUE,
        xlab="Evaluations", ylab="Density", breaks=NULL, cex=0.7,
		scales=list(relation="free"), 
	    panel = function(x, ...) {
	        panel.histogram(x, ...) 

    		param <- fitdistr(x, densfun="weibull", lower=c(0.01,0.01))$estimate
 	  		llines(1:max(x), dweibull(1:max(x), shape=param[1],scale=param[2]), col="green")
			param <- fitdistr(x, densfun="Lognormal")$estimate
			llines(1:max(x),dlnorm(1:max(x), meanlog=param[1], sdlog=param[2], log=F), col="black")
			param <- fitdistr(x, densfun="normal")$estimate
			llines(1:max(x),dnorm(1:max(x), mean=param[1], sd=param[2], log=F), col="blue")
			#xscaled <- (x-min(x))/max(x)
			#mu <- mean(xscaled)
			#var <- sd(xscaled)
			#alpha <- (((1 - mu) /(var^2)) - (1 / mu)) * mu ^ 2
			#beta <- alpha * (1 / (mu - 1))
			#print(paste(alpha, beta))
			#param <- fitdistr(xscaled, densfun="beta")$estimate
			#llines(1:max(x),max(x)*dbeta(1:max(x), shape1=alpha, shape2=beta, log=F)+min(x), col="blue")
			
	        #panel.mathdensity(dmath = norm, col = "black", args = list(mean=param[1],prob=param[2])) 
		})

dev.copy2eps(file="histogram-fit.eps",  fonts="ComputerModern")
while(1) Sys.sleep(1)
