#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)

data <-read.table("../simples/parity/simple/measures/k-notaccumulated.dat", header=F)
data <- data$V1
data <- data[data<800]
#data <- data[data<400]
#data <- data[data>60]
#data <- data-60

x11()

par(mfrow=c(3,2))

generaciones <- 1:1000

param <- fitdistr(data, densfun="geometric")$estimate
his <- hist(data, freq=F, main="Geometric",breaks=20)
rug(data)
lines(dgeom(generaciones, param), col="red")

print(his$breaks)
print(his$density)
print(his$counts)
data <- data.frame(x=his$breaks[1:length(his$breaks)-1], y=log(his$counts))

print(data)
names(his)
plot(data$x, data$y, ylab="log(density)")

lm.r <- lm(y ~ x, data=data)
abline(lm.r)

summary(lm.r)
plot(lm.r)

#dev.copy2pdf(file="modelo-linear-noaleatorio.pdf");

while(1) Sys.sleep(10)
