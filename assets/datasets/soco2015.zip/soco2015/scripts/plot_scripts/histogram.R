#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c("../simples/ant/simple/measures/k-notaccumulated.dat", 
           "../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat") 
labels <- c("Artificial ant", "Regression", "4-Parity", "5-Parity", "6-Multiplexer", "11-Multiplexer")
distributions <- c("Normal", "Lognormal", "Weibull", "Logistic")

x11()

par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

i <- 1
for (file in files) {
    print(file)
    print(i)
    data <-read.table(file, header=F)
    data <- data$V1

    x <-5*(1:10)
    y <- rep(c(FALSE, FALSE, FALSE, FALSE, TRUE), 10)

    gens <- 1:50
    breaks <- 0:50

    if (i == 4)  {
       data <- data[data<800]
       breaks <- 40
       gens <- 1:800
       x <-(1:10) * 80
       y <- rep(c(rep(FALSE, 79), TRUE))
    } else if (i==6) {
	   gens <- 1:800
	   breaks <- 30
       x <-(1:10) * 80
       y <- rep(c(rep(FALSE, 79), TRUE))
	}
    
    hist(data, freq=F, breaks=breaks, xlab="Generation-to-success", main=labels[i], lwd=0.1)

    param <- fitdistr(data, densfun="normal")$estimate
    point <- dnorm(gens, mean=param[1], sd=param[2], log=F)
    lines(point, col=2, lty=2, lwd=1.2)
    points(x, point[y==TRUE], col=2, pch=2)
#	points(dnorm(1:50, mean=param[1], sd=param[2], log=F), col=1, lty=2, pch=2)

	  param <- fitdistr(data, densfun="Lognormal")$estimate
    point <- dlnorm(gens, meanlog=param[1], sdlog=param[2], log=F)
	print("mean:")
	print(param[1])
	print("sd")
	print(param[2])
#    print(length(point))
	  lines(point, col=1, lty=1, pch=1, lwd=1.2)
    points(x, point[y==TRUE], col=1, pch=1)

    param <- fitdistr(data, densfun="Weibull")$estimate
    point <- dweibull(gens, shape=param[1], scale=param[2], log=F)
    lines(point, col=3, lty=3, pch=3, lwd=1.2)
    points(x, point[y==TRUE], col=3, lty=3, pch=3)

    param <- fitdistr(data, densfun="Logistic")$estimate
    point <- dlogis(gens, location=param[1], scale=param[2], log=F)
    lines(point, col=4, lty=4, pch=4, lwd=1.2)
    points(x, point[y==TRUE], col=4, lty=4, pch=4)

    #param <- fitdistr(data, densfun="t")$estimate 
	#point <- dt(1:50, df=param[3], ncp=param[1], log=F) 
	#lines(point, col=5, lty=5, pch=5) 
	#points(x, point[y==TRUE], col=5, lty=5, pch=5)
				
  if (i == 6) { # Last histogram 
		legend("topright", distributions, bty="n", 
			cex=0.9, col=c(2,1,3,4), lty=c(2,1,3,4), pch=c(2,1,3,4), lwd=1.2) 
	}
    
	i <- i+1 
}

dev.copy2eps(file="../../../tex/figs/histogram.eps",fonts="ComputerModern"); 
while(1) Sys.sleep(1)
#q() 
