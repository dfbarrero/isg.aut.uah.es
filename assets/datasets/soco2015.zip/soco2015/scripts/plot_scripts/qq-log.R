#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(lattice)

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

data <- read.table(file="../data.dat", header=T)
x11()

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

qqmath(~ log(evaluations)|problem, data=data, xlab="Normal", ylab="log(evaluations)",
       prepanel = prepanel.qqmathline,
	   aspect = "y", as.table=TRUE, envelope=T,
#	   index.cond=list(c(5,2,4,6,3,1)),
	   panel = function(x, ...) {
	         panel.qqmathline(x, ...)
	         panel.qqmath(x, ...)
	   })

#dev.copy2eps(file="../../../tex/figs/qq-log.eps",  fonts="ComputerModern"); 
while(1) Sys.sleep(1)
