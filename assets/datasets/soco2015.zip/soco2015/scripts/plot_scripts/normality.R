#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(lattice)
library(MASS)

win <- TRUE

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

file <- c("../data.dat")

result <- data.frame(problem=NULL, mu=NULL, sigma=NULL, W=NULL, p.value=NULL)
dataset <- read.table(file, header=T)
print(colnames(dataset))

for (algorithm in unique(dataset$problem)) {
	p <- algorithm # Without it, it does not work (?)

	data <- subset(dataset, problem==p)
	print(p)
	print(nrow(data))
	print("---")

	data <- data$evaluations
	#print(shapiro.test(data))
	p <- shapiro.test((data))$p.value
	w <- shapiro.test((data))$statistic
	#print(paste(algorithm, obstacles))

	param <- fitdistr(data, densfun="Lognormal")$estimate
	result <- rbind(result, data.frame(problem=algorithm, mu=param[1], sigma=param[2], W=w, p.value=p))
	data <- NULL
}

print(result)
