#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(lattice)

win <- TRUE

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c("../simples/ant/simple/measures/k-notaccumulated.dat", 
           "../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat") 

labels <- c("Artificial ant", "Regression", "4-Parity", "5-Parity", "6-Multiplexer", "11-Multiplexer")
distributions <- c("Normal", "Lognormal", "Weibull", "Logistic")

data <- data.frame(problem=NULL, g=NULL)

if (win) x11()

par(mfrow=c(2,3), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

i <- 1
for (file in files) {
    print(file)
    g <-read.table(file, header=F)
    g <- g$V1
    g <- g[g<800]
	g <- log(g)

	data <- rbind(data, data.frame(problem=labels[i], g=g))
	i <- i+1
}

#print(data)
histogram(~ g|problem, data=data, col="red", 
	type = "density", xlab="log(generation-to-success)",
	layout = c(3,2), aspect="y",
    panel = function(x, ...) {
	     panel.histogram(x, ...)
	     panel.mathdensity(dmath = dnorm, col = "black",
	     args = list(mean=mean(x),sd=sd(x)))
	}
)#, scales=list(relation="free"))

#qqmath(~ g|problem, data=data,
#       prepanel = prepanel.qqmathline,
#	   panel = function(x, ...) {
#	         panel.qqmathline(x, ...)
#	         panel.qqmath(x, ...)
#	   })

#qqmath(~ g|problem, data=data)#, scales=list(relation="free"))

dev.copy2eps(file="../../../tex/figs/histogram-log.eps",  fonts="ComputerModern"); 
print("OK")
if(win) while(1) Sys.sleep(1)
