#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c("es.dat") 
distributions <- c("Normal", "Lognormal", "Weibull", "Logistic")

x11()

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

i <- 1
for (file in files) {
    print(file)
    print(i)
    data <-read.table(file, header=F)
    data <- data$V1
	data <- data[data<max(data)]

    hist(data, freq=F, xlab="Evaluations-to-success", lwd=0.1)

	gens <- 1:max(data)

    param <- fitdistr(data, densfun="normal")$estimate
    point <- dnorm(gens, mean=param[1], sd=param[2], log=F)
    lines(point, col=2, lty=2, lwd=1.2)
#	points(dnorm(1:50, mean=param[1], sd=param[2], log=F), col=1, lty=2, pch=2)

	param <- fitdistr(data, densfun="Lognormal")$estimate
    point <- dlnorm(gens, meanlog=param[1], sdlog=param[2], log=F)
	print("mean:")
	print(param[1])
	print("sd")
	print(param[2])
#    print(length(point))
	lines(point, col=1, lty=1, pch=1, lwd=1.2)

    param <- fitdistr(data, densfun="Weibull")$estimate
    point <- dweibull(gens, shape=param[1], scale=param[2], log=F)
    lines(point, col=3, lty=3, pch=3, lwd=1.2)

    param <- fitdistr(data, densfun="Logistic")$estimate
    point <- dlogis(gens, location=param[1], scale=param[2], log=F)
    lines(point, col=4, lty=4, pch=4, lwd=1.2)

	legend("topright", distributions, bty="n", 
		cex=0.9, col=c(2,1,3,4), lty=c(2,1,3,4), pch=c(2,1,3,4), lwd=1.2) 
    
	i <- i+1 
}

#dev.copy2eps(file="../../../tex/figs/histogram.eps",fonts="ComputerModern"); 
while(1) Sys.sleep(1)
#q() 
