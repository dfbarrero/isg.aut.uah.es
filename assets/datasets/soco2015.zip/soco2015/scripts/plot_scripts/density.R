#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(lattice)
library(latticeExtra)

print("hola")
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

file <- c( "../data-tour.dat")
#labels <- factor(c("A*", "Basic Theta", "H-Theta"), ordered=TRUE)

#if (win) x11(width=8, height=6)

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

a <- read.table(file, header=T)
colnames(a)
x11()

#densityplot(~ evaluations | problem, data=a, plot.points=F, col="red",
ecdfplot(~ evaluations | problem, data=a, plot.points=F, col="black",
        #scales=list(relation="free"), as.table=TRUE, layout=c(3,2),aspect="y",
        xlab="Run-time (evaluations)", ylab="Density", breaks=NULL, cex=0.5, layout=c(4,4), as.table=T,
		scales=list(relation="free", x=list(log=F)), auto.key=list(space="right"), 
		#auto.key = list(text = c("Lognormal","Weibull", "Exponential"), columns=3, col=c("blue", "green", "black"), lines=TRUE, points=FALSE),
		#key = simpleKey(text = c("Lognormal","Weibull", "Normal", "Gamma"), columns=3, lines=TRUE, points=FALSE, col=c("black", "green", "blue", "brown")),
#	   index.cond=list(c(5,2,4,6,3,1)),
	    panel = function(x, ...) {
	        panel.densityplot(x, ...) 
	        #panel.ecdfplot(x, ...) 

    		param <- fitdistr(x, densfun="weibull",lower=c(0.01,0.01))$estimate
 	  		#llines(1:max(x), pweibull(1:max(x), shape=param[1],scale=param[2]), col="red")
 	  		llines(1:max(x), dweibull(1:max(x), shape=param[1],scale=param[2]), col="red")
			param <- fitdistr(x, densfun="Lognormal")$estimate
			#llines(1:max(x),plnorm(1:max(x), meanlog=param[1], sdlog=param[2], log=F), col="blue")
			llines(1:max(x),dlnorm(1:max(x), meanlog=param[1], sdlog=param[2], log=F), col="blue")
			#param <- fitdistr(x, densfun="normal")$estimate
			#llines(1:max(x),pnorm(1:max(x), mean=param[1], sd=param[2], log=F), col="blue")

			#llines(1:max(x),dnorm(1:max(x), shape=param[1], rate=param[2], log=F), col="brown")
			#print(param)
	        #panel.mathdensity(dmath = norm, col = "black", args = list(mean=param[1],prob=param[2])) 
		})

dev.copy2eps(file="density.eps",  fonts="ComputerModern")
while(1) Sys.sleep(1)
