#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(lattice)

data <- read.table("ks-data.dat", header=T)

x11()
xyplot(p.value~log(AES)|distribution, data, pch=19, 
		auto.key=F, ylab="K-S test p-value", groups=problem,  aspect=0.5,
		panel = function(x, y, subscripts, groups=problem, ...){
			panel.xyplot(x, y, ...)
			panel.abline(h=0.05, col="grey", lty="dashed")
			ltext(x = x, y = y+0.04, labels = groups[subscripts], cex=0.8, col="grey",
			                  fontfamily = "HersheySans")
			panel.lmline(x, y, col=2)
		}
	)

print("Computing correlation coefficient")
matrix <- c(NULL, NULL)


dev.copy2eps(file="ks-scatterplot.eps",  fonts="ComputerModern")
while(1) Sys.sleep(1)
