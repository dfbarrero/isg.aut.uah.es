#!/usr/bin/Rscript --vanilla
library(binom)

data <- read.csv("dataset.csv", header=T)

for (problem in unique(data$problem)) {
	p <- problem
	a <- subset(data, problem==p&tournament==7)
	a <- a$evaluations[a$evaluations < max(a$evaluations)]	
	if (length(a) > 0) {
		print(paste("7: ", p, length(a)+2, (length(a)+2)/500))
			#format(binom.wilson(length(a)+2, 500)$lower, digits=3),
			#format(binom.wilson(length(a)+2, 500)$upper, digits=3)))
	}
}

for (problem in unique(data$problem)) {
	p <- problem
	a <- subset(data, problem==p&tournament==1)
	a <- a$evaluations[a$evaluations < max(a$evaluations)]	
	if (length(a) > 0) {
		print(paste("1: ", p, length(a)+2, (length(a)+2)/500))
			#format(binom.wilson(length(a)+2, 500)$lower, digits=3),
			#format(binom.wilson(length(a)+2, 500)$upper, digits=3)))
	}
}
