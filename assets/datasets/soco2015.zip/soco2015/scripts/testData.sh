#!/bin/bash

for I in data/*
do
	echo $I `wc -l< $I/es.dat`
	#echo $I `ls -l $I/*gz |wc -l` `wc -l< $I/es.dat`
done
