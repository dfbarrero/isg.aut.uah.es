#!/usr/bin/Rscript --vanilla

library(lattice)
#library(Hmisc)
library(xtable)

data <- read.table("data.dat", header=T)

result <- data.frame(problem=NULL, w=NULL, p=NULL)

for (problem in unique(data$problem)) {
	print(paste("Doing ", problem))

	b <- problem

	ds <- subset(data, problem==b)$evaluations

	if (length(ds) > 100) ds <- sample(ds, 100)

	norm <- shapiro.test(log(ds))
	print(problem)
	print(norm)

	df <- data.frame(problem=problem, w=norm$statistic, p=norm$p.value)
	result <- rbind(result, df)
}

print("------")
fm1.table <- xtable(result, digits=3)
#print(fm1.table)
print(fm1.table,type="latex")
#print(summary(result),type="latex")
