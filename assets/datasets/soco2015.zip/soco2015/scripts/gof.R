#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(fitdistrplus)
library(xtable)

#options(digits=1)

print("hola")
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

file <- c("data.dat")

data <- read.table(file, header=T)
colnames(data)
x11()

par(mfrow=c(2,3))
print(nrow(data))

result <- data.frame(problem=NULL, 
	ksw=NULL, kswt=NULL, adw=NULL, adwt=NULL,
	ksl=NULL, kslt=NULL, adl=NULL, adlt=NULL)

for (problem in unique(data$problem)) {
	print(problem)
	p <- problem
	
	if (p == "multi11-gp") next
	if (p == "quintic-gp-erc") next

	sdata <- subset(data, problem==p)$evaluations
	sdata <- sample(sdata, 50)
	#print(paste("Datos: "), length(sdata))
	print("weibull")
	fw <- fitdist(sdata, "weibull")
	fwr<-gofstat(fw, print=T)
	print(str(fwr))
	fwr$ks <- fwr$ks
	fwr$t <- fwr$kstest

	print("lnorm")
	fl <- fitdist(sdata, "lnorm")
	flr<-gofstat(fl, print=T)
	flr$ks <- flr$ad
	flr$kst <- flr$adtest

	#res <- cdfcomp(list(fw,fln),legendtext=c("Weibull","lognormal"), xlab="serving sizes (g)",lwd=2)
	#print(str(flr))
	
	temp <- data.frame(problem=p,
	    ksw=fwr$ks, kswt=fwr$kstest, adw=fwr$ad, adwt=fwr$adtest,
		ksl=flr$ks, kslt=flr$kstest, adl=flr$ad, adlt=flr$adtest)
		
	result <- rbind(result, temp)
}

print(result)
#fm1.table <- xtable(result, digits=2)
#print(fm1.table,type="latex")
while(1) Sys.sleep(1)
