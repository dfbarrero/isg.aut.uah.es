#!/bin/bash 

# Paths
BASE=/Users/david/Documents/investigacion/repositorios/gp+em2011/trunk/code/

DATA=$1

if [ $# -ne 1 ]
then
	echo SYNTAX: $0 directory
	exit 
fi

# Clean data
# Remove comments if data is already clean (there is no new executions)

#echo Cleaning data
#for file in data/*
#do
#	tr -d [ < $file | tr -d ] | tr \| " " > temp && mv temp $file
#done

echo "Extracting Successes"
FILE=$DATA/es.dat
#echo "#Evaluations" > $FILE
cat $DATA/job.*.simple |grep Evaluations |cut -d ":" -f 2 > $FILE

#exit
#echo "Calculating K(M, i)"
#L3C_ALL=C awk '
#	{ 
#		if (FNR == 1) file++

#	 	if ('\$$SR_COLUMN' '$SR_CONDITION' '$SR_FITNESS') {
#			for (i = FNR; i< '$GENERATIONS'; i++) {
#				k[i, file] = 1
#			}
#			nextfile
#		} else {
#			k[FNR, file] = 0
#		}

#	 } END {
#	 	for (y=1; y<'$GENERATIONS'; y++) {
#			line = ""
#			for (x=1; x<=file; x++) {
#				line = line k[y, x] " "
#			}
#			print line
#		}
#	 } ' data/run-* > measures/k.dat

#echo "Estimating SR"
#LC_ALL=C awk '
#	{ 
#	 	if ('\$$SR_COLUMN' '$SR_CONDITION' '$SR_FITNESS') {
#			k[FNR] = k[FNR] + 1
#				nextfile
#			} else if (k[FNR] > 0) {
#				k[FNR] = k[FNR]
#			} else {
#				k[FNR] = 0
#			}
#
#		 } END {
#			accumulative[0] = 0
#			for (x=1; x<'$GENERATIONS'; x++) {
#				if (k[x] > 0)
#					accumulative[x] = accumulative[x-1] + k[x]
#				else
#					accumulative[x] = accumulative[x-1]
#			}

#			y = 0
#		 	for (x=0; x<'$GENERATIONS'; x++) {
#				y = k[x]/(ARGC-1)
#				y2 = accumulative[x]/(ARGC-1)

#				print x "\t" accumulative[x] "\t\t" y2
#			}
#	 } ' data/run-* > measures/sr.dat
	
#	 echo Estimating koza computational effort
#	 LC_ALL=C awk ' BEGIN {
#				epsilon='$KOZA_E'
#				population='$POPULATION'
#				i=0
#				print "Gen\tP\tI\tInoceil\tdiff"
#			}	{
#				i++
#				if ($3 != 0) {
#					R=int(log(epsilon)/log(1-$3))
#					Rnoceil=log(epsilon)/log(1-$3)
#					print i "\t" $3 "\t" R*i*population "\t" Rnoceil*i*population "\t" (Rnoceil*i*population)-(R*i*population)
#				} else print i "\t" $3 "\t NaN \t NaN \t NaN"
#	}' measures/sr.dat > measures/koza.dat
	
